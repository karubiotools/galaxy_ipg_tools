#!/bin/bash

input=$1
output=$2


directory=`dirname $0`

perl $directory/nucleScore.pl $input_files $output   

#perl $directory/nucleScore.pl `echo $input | tr ',' ' '`  $output


