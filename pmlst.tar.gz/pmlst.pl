#!/usr/bin/perl -w
use strict;
use warnings;   

my $STpmlst = "";

my $path = $ARGV[0];
my $seq = $ARGV[1];
my $scheme = $ARGV[2];


open PMLST, "python3 $path/pmlst/pmlst.py -i $seq -s $scheme -p $path/pmlst/pmlst_db/ |";
while (<PMLST>) {
     chomp ($_);
    if ($_ =~ "sequence_type") {
        #print "ST:$_ \n";
        my @table = split (/:/,$_);
        $STpmlst = $table [1];
        #chomp ($STpmlst); $STpmlst = chop($STpmlst);
        $STpmlst =~ s/\s+//;
        $STpmlst = substr($STpmlst,1);
	my @table2 = split (/'/,$STpmlst);
	$STpmlst = $table2[0];
        #print "$STpmlst\n" ;
    }
}

#print "Sequence\tSequence Type (pMLST)\n" ;
print "pMLST for $seq:\t$STpmlst\n" ;
